{% macro my_udf() %}
CREATE OR REPLACE FUNCTION DBT_DEPLOY_DB.DBT_DEPLOY_SCHEMA.AREA_OF_SQUARE(RADIUS FLOAT)
    RETURNS FLOAT
        AS 
            $$
            RADIUS * RADIUS
            $$
            ;
{% endmacro %}