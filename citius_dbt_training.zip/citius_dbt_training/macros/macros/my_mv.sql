{% macro my_mv() %}

CREATE OR REPLACE materialized VIEW reviews_materialized
as
(
select * from {{ source('dbt_deploy_db','alpha_reviews') }}
)

{% endmacro %}