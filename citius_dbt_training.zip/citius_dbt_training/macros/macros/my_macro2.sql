{% macro my_macro2(model) %}
SELECT 
*
FROM
    {{ model }}
WHERE
    {%  for col in adapter.get_columns_in_relation(model)  -%}
        {{ col.column }} is NULL
        or
    {% endfor %} 
    false
{% endmacro %}