{% macro my_mv2() %}

CREATE OR REPLACE materialized VIEW hosts_materialized
as
(
select * from {{ source('dbt_deploy_db','alpha_hosts') }}
)

{% endmacro %}