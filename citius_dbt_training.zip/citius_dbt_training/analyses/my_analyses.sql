select 
* 
from {{ ref('fact_reviews') }} r
inner JOIN
    {{ ref('dim_listing_cleansed') }} l
on r.listing_id = l.listing_id
where r.review_date < l.created_at