{% snapshot scd_raw_listings %}

{{ config(
    target_schema = 'DBT_DEPLOY_SCHEMA',
    unique_key = 'id',
    strategy = 'timestamp',
    updated_at = 'updated_at',
    invalidate_hard_deletes = true

) }} 


select * from {{ source('dbt_deploy_db','alpha_listings') }}

{% endsnapshot %}