

with model_3 as (

select * from 
{{source('dbt_deploy_db','alpha_hosts')}}

)

SELECT 
ID AS HOST_ID,
NAME AS HOST_NAME,
IS_SUPERHOST,
CREATED_AT,
updated_at

FROM 
MODEL_3 