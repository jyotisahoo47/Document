WITH MODEL_4 
    AS
        (
            SELECT * FROM
                {{ref('src_hosts')}}
        )


SELECT 
    HOST_ID,
    NVL(HOST_NAME,'AMBIGIOUS') AS HOST_NAME,
    IS_SUPERHOST,
    CREATED_AT,
    UPDATED_AT
FROM 
    MODEL_4
