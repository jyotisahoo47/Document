WITH 
MODEL_7_A
    AS
        (
            SELECT * FROM
                {{ref('dim_host_cleansed')}}
        )
        ,

MODEL_7_B
    AS  
    (
        SELECT * FROM
                {{ref('dim_listing_cleansed')}}
    )    

SELECT 
    B.listing_id,
    B.listing_name,
    B.room_type,
    B.minimum_nights,
    B.price,
    B.HOST_ID,
    A.HOST_NAME,
    A.IS_SUPERHOST AS HOST_IS_SUPERHOST,
    A.CREATED_AT,
    GREATEST(A.UPDATED_AT,B.UPDATED_AT) AS UPDATED_AT
FROM 
    MODEL_7_B B
LEFT JOIN 
    MODEL_7_A A
ON B.HOST_ID = A.HOST_ID

